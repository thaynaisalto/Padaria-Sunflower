public class Produtos {
    public static void main(String[] args) {
    }
}
